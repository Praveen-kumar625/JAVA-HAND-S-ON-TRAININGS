In this folder, you'll find two folders :
- The client.
- The server.